"""
Pesaje - Egreso
Muestra tickets de ingreso disponibles y permite vincular egreso
"""
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import datetime
from core import theme as T
from core.session import Sesion
from core.database import (
    get_proximo_ticket, 
    guardar_ticket_egreso,
    listar_tickets_ingreso_abiertos,
    get_ticket_by_id
)


class PesajeEgreso(tk.Frame):
    def __init__(self, master, on_back):
        super().__init__(master, bg=T.FONDO)
        self.on_back = on_back
        self.tipo_op = None
        self.ticket_ingreso = None
        self._build()

    def _build(self):
        header = tk.Frame(self, bg=T.VERDE, height=50)
        header.pack(fill="x")
        header.pack_propagate(False)

        tk.Button(header, text="← Volver", font=T.FONT_LABEL, bg=T.ROJO, fg=T.TEXTO_CLARO, 
                  relief="flat", cursor="hand2", command=self.on_back).pack(side="left", padx=10, pady=8)
        tk.Label(header, text="📤 EGRESO - Pesaje de Salida", font=T.FONT_SUBTITULO, 
                 bg=T.VERDE, fg=T.TEXTO_CLARO).pack(side="left", padx=15, pady=10)

        self.content = tk.Frame(self, bg=T.FONDO)
        self.content.pack(expand=True, fill="both", padx=20, pady=15)
        
        self._show_tickets_disponibles()

    def _show_tickets_disponibles(self):
        """Muestra la lista de tickets de ingreso disponibles"""
        for w in self.content.winfo_children():
            w.destroy()

        # Panel superior con info
        info_frame = tk.Frame(self.content, bg=T.BLANCO, relief="solid", bd=1)
        info_frame.pack(fill="x", pady=(0, 15))

        tk.Label(info_frame, text="📋 TICKETS DE INGRESO DISPONIBLES", 
                 font=T.FONT_SUBTITULO, bg=T.BLANCO, fg=T.AZUL).pack(pady=10)
        tk.Label(info_frame, text="Seleccione un ticket de ingreso para registrar el egreso", 
                 font=T.FONT_LABEL, bg=T.BLANCO, fg=T.GRIS_OSCURO).pack(pady=(0, 10))

        # Filtros
        filtros_frame = tk.Frame(self.content, bg=T.BLANCO, relief="solid", bd=1)
        filtros_frame.pack(fill="x", pady=(0, 10))

        row = tk.Frame(filtros_frame, bg=T.BLANCO)
        row.pack(fill="x", padx=10, pady=8)

        tk.Label(row, text="Buscar patente:", font=T.FONT_LABEL, bg=T.BLANCO, fg=T.TEXTO).pack(side="left", padx=5)
        self.entry_buscar = tk.Entry(row, font=T.FONT_NORMAL, bg=T.GRIS_CLARO, width=15, relief="solid", bd=1)
        self.entry_buscar.pack(side="left", padx=5)
        self.entry_buscar.bind("<KeyRelease>", self._filtrar)

        tk.Button(row, text="🔄 Actualizar", font=T.FONT_LABEL, bg=T.AZUL, fg=T.TEXTO_CLARO, 
                  relief="flat", cursor="hand2", command=self._cargar_tickets).pack(side="left", padx=15)

        # Tabla de tickets
        tabla_frame = tk.Frame(self.content, bg=T.BLANCO, relief="solid", bd=1)
        tabla_frame.pack(expand=True, fill="both")

        # Scrollbar
        scroll = ttk.Scrollbar(tabla_frame)
        scroll.pack(side="right", fill="y")

        cols = ("ticket", "fecha", "patente_chasis", "patente_acoplado", "transportista", "peso", "estado")
        self.tree = ttk.Treeview(tabla_frame, columns=cols, show="headings", 
                                  yscrollcommand=scroll.set, height=15)

        headers = [
            ("ticket", "Ticket Ingreso", 130),
            ("fecha", "Fecha/Hora", 130),
            ("patente_chasis", "Pat. Chasis", 90),
            ("patente_acoplado", "Pat. Acoplado", 90),
            ("transportista", "Transportista", 180),
            ("peso", "Peso (kg)", 100),
            ("estado", "Estado", 80)
        ]

        for col_id, text, width in headers:
            self.tree.heading(col_id, text=text)
            self.tree.column(col_id, width=width, minwidth=50)

        scroll.config(command=self.tree.yview)
        self.tree.pack(fill="both", expand=True, padx=5, pady=5)

        # Doble click para seleccionar
        self.tree.bind("<Double-1>", self._seleccionar_ticket)
        self.tree.bind("<Return>", self._seleccionar_ticket)

        # Botones
        btn_frame = tk.Frame(self.content, bg=T.FONDO)
        btn_frame.pack(pady=15)

        tk.Button(btn_frame, text="✅ SELECCIONAR TICKET", font=T.FONT_BOTON, bg=T.VERDE, 
                  fg=T.TEXTO_CLARO, relief="flat", cursor="hand2", padx=20, pady=8,
                  command=self._seleccionar_ticket_click).pack(side="left", padx=10)

        tk.Label(btn_frame, text="Doble click en un ticket para seleccionarlo", 
                 font=T.FONT_LABEL, bg=T.FONDO, fg=T.GRIS_OSCURO).pack(side="left", padx=20)

        # Cargar datos
        self._cargar_tickets()

    def _cargar_tickets(self):
        """Carga los tickets de ingreso disponibles"""
        for item in self.tree.get_children():
            self.tree.delete(item)

        tickets = listar_tickets_ingreso_abiertos()
        self.tickets_map = {}

        for t in tickets:
            item_id = self.tree.insert("", "end", values=(
                t.get('numero_ticket', ''),
                f"{t.get('fecha', '')} {t.get('hora', '')}",
                t.get('patente_chasis', ''),
                t.get('patente_acoplado', ''),
                t.get('transportista', '') or '-',
                f"{t.get('peso_kg', 0):,.0f}",
                t.get('estado', 'abierto').upper()
            ))
            self.tickets_map[item_id] = t

        if not tickets:
            self.tree.insert("", "end", values=("- No hay tickets de ingreso disponibles -", "", "", "", "", "", ""))

    def _filtrar(self, event=None):
        """Filtra la tabla por patente"""
        buscar = self.entry_buscar.get().strip().upper()
        
        for item in self.tree.get_children():
            self.tree.delete(item)

        tickets = listar_tickets_ingreso_abiertos()
        self.tickets_map = {}

        for t in tickets:
            # Filtrar por patente
            patente_chasis = (t.get('patente_chasis', '') or '').upper()
            patente_acoplado = (t.get('patente_acoplado', '') or '').upper()
            
            if buscar and buscar not in patente_chasis and buscar not in patente_acoplado:
                continue

            item_id = self.tree.insert("", "end", values=(
                t.get('numero_ticket', ''),
                f"{t.get('fecha', '')} {t.get('hora', '')}",
                t.get('patente_chasis', ''),
                t.get('patente_acoplado', ''),
                t.get('transportista', '') or '-',
                f"{t.get('peso_kg', 0):,.0f}",
                t.get('estado', 'abierto').upper()
            ))
            self.tickets_map[item_id] = t

    def _seleccionar_ticket_click(self):
        """Selecciona el ticket desde el botón"""
        selection = self.tree.selection()
        if not selection:
            messagebox.showwarning("Atención", "Seleccione un ticket de ingreso")
            return
        
        item_id = selection[0]
        if item_id not in self.tickets_map:
            messagebox.showwarning("Atención", "Seleccione un ticket válido")
            return

        self.ticket_ingreso = self.tickets_map[item_id]
        self._show_tipo_selector()

    def _seleccionar_ticket(self, event=None):
        """Selecciona el ticket con doble click"""
        selection = self.tree.selection()
        if not selection:
            return
        
        item_id = selection[0]
        if item_id not in self.tickets_map:
            return

        self.ticket_ingreso = self.tickets_map[item_id]
        self._show_tipo_selector()

    def _show_tipo_selector(self):
        """Muestra selector de tipo de egreso"""
        for w in self.content.winfo_children():
            w.destroy()

        # Info del ticket seleccionado
        info_frame = tk.Frame(self.content, bg=T.BLANCO, relief="solid", bd=1)
        info_frame.pack(fill="x", pady=10)

        tk.Label(info_frame, text="📄 TICKET DE INGRESO SELECCIONADO", 
                 font=T.FONT_BOTON, bg=T.BLANCO, fg=T.AZUL).pack(anchor="w", padx=15, pady=(10, 5))

        info = f"N°: {self.ticket_ingreso['numero_ticket']} | Fecha: {self.ticket_ingreso['fecha']} {self.ticket_ingreso['hora']}\n"
        info += f"Patente: {self.ticket_ingreso.get('patente_chasis', '-')} / {self.ticket_ingreso.get('patente_acoplado', '-')}\n"
        info += f"Transportista: {self.ticket_ingreso.get('transportista', '-')} | Peso: {self.ticket_ingreso.get('peso_kg', 0):,.0f} kg"

        tk.Label(info_frame, text=info, font=T.FONT_NORMAL, bg=T.BLANCO, 
                 fg=T.TEXTO, justify="left").pack(anchor="w", padx=15, pady=(0, 10))

        # Selector de tipo
        tk.Label(self.content, text="Seleccione tipo de egreso:", font=T.FONT_SUBTITULO, 
                 bg=T.FONDO, fg=T.TEXTO).pack(pady=30)

        frame = tk.Frame(self.content, bg=T.FONDO)
        frame.pack()

        tipos = [
            ("🚛 CAMIÓN VACÍO", "Pesaje de tara - El camión regresa vacío", "vacio"),
            ("📦 CAMIÓN CON MERCANCÍA", "Pesaje bruto de salida - El camión lleva carga", "mercancia")
        ]

        for titulo, desc, tipo in tipos:
            self._make_tipo_btn(frame, titulo, desc, tipo)

        # Botón volver
        tk.Button(self.content, text="← Volver a lista", font=T.FONT_LABEL, bg=T.GRIS_OSCURO, 
                  fg=T.TEXTO_CLARO, relief="flat", cursor="hand2", 
                  command=self._show_tickets_disponibles).pack(pady=20)

    def _make_tipo_btn(self, parent, titulo, desc, tipo):
        btn = tk.Frame(parent, bg=T.BLANCO, relief="solid", bd=1, cursor="hand2")
        btn.pack(fill="x", pady=8, padx=20)

        tk.Label(btn, text=titulo, font=T.FONT_BOTON, bg=T.BLANCO, fg=T.VERDE).pack(pady=(15, 0))
        tk.Label(btn, text=desc, font=T.FONT_LABEL, bg=T.BLANCO, fg=T.GRIS_OSCURO).pack(pady=(0, 15))

        def on_click(e):
            self.tipo_op = tipo
            self._show_form()

        def on_enter(e):
            btn.configure(bg=T.GRIS_CLARO)
            for w in btn.winfo_children():
                w.configure(bg=T.GRIS_CLARO)

        def on_leave(e):
            btn.configure(bg=T.BLANCO)
            for w in btn.winfo_children():
                w.configure(bg=T.BLANCO)

        btn.bind("<Button-1>", on_click)
        btn.bind("<Enter>", on_enter)
        btn.bind("<Leave>", on_leave)
        for c in btn.winfo_children():
            c.bind("<Button-1>", on_click)

    def _show_form(self):
        """Muestra el formulario de pesaje de egreso"""
        for w in self.content.winfo_children():
            w.destroy()

        canvas = tk.Canvas(self.content, bg=T.FONDO, highlightthickness=0)
        scrollbar = tk.Scrollbar(self.content, orient="vertical", command=canvas.yview)
        scroll_frame = tk.Frame(canvas, bg=T.FONDO)

        scroll_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=scroll_frame, anchor="nw", width=self.content.winfo_width()-20)
        canvas.configure(yscrollcommand=scrollbar.set)

        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        # Info del ticket de ingreso
        info_in = tk.Frame(scroll_frame, bg=T.BLANCO, relief="solid", bd=1)
        info_in.pack(fill="x", padx=20, pady=10)

        tk.Label(info_in, text="📄 TICKET DE INGRESO (Se cerrará después del egreso)", 
                 font=T.FONT_BOTON, bg=T.BLANCO, fg=T.ROJO).pack(anchor="w", padx=15, pady=(10, 5))

        info = f"N°: {self.ticket_ingreso['numero_ticket']}\n"
        info += f"Fecha: {self.ticket_ingreso['fecha']} {self.ticket_ingreso['hora']}\n"
        info += f"Patente: {self.ticket_ingreso.get('patente_chasis', '-')} / {self.ticket_ingreso.get('patente_acoplado', '-')}\n"
        info += f"Transportista: {self.ticket_ingreso.get('transportista', '-')}\n"
        info += f"Peso registrado: {self.ticket_ingreso.get('peso_kg', 0):,.0f} kg"

        tk.Label(info_in, text=info, font=T.FONT_NORMAL, bg=T.BLANCO, 
                 fg=T.TEXTO, justify="left").pack(anchor="w", padx=15, pady=(0, 10))

        # Nuevo ticket de egreso
        ticket = get_proximo_ticket("egreso")
        self.ticket_egreso = ticket

        info_out = tk.Frame(scroll_frame, bg=T.VERDE)
        info_out.pack(fill="x", padx=20, pady=10)

        tk.Label(info_out, text=f"Nuevo Ticket Egreso: {ticket}", font=T.FONT_BOTON, 
                 bg=T.VERDE, fg=T.TEXTO_CLARO).pack(side="left", padx=15, pady=10)
        tk.Label(info_out, text=f"Tipo: {'VACÍO' if self.tipo_op == 'vacio' else 'CON MERCANCÍA'}", 
                 font=T.FONT_LABEL, bg=T.VERDE, fg=T.TEXTO_CLARO).pack(side="left", padx=20, pady=10)
        tk.Label(info_out, text=f"Fecha: {datetime.now().strftime('%d/%m/%Y %H:%M')}", 
                 font=T.FONT_NORMAL, bg=T.VERDE, fg=T.TEXTO_CLARO).pack(side="right", padx=15, pady=10)

        # Pesaje
        peso_frame = tk.Frame(scroll_frame, bg=T.BLANCO, relief="solid", bd=1)
        peso_frame.pack(fill="x", padx=20, pady=15)

        tk.Label(peso_frame, text="⚖️ PESAJE DE EGRESO", font=T.FONT_SUBTITULO, 
                 bg=T.BLANCO, fg=T.AZUL).pack(pady=10)

        self.lbl_peso = tk.Label(peso_frame, text="0 kg", font=T.FONT_MONO, 
                                  bg=T.FONDO, fg=T.VERDE, width=12, relief="solid", bd=2)
        self.lbl_peso.pack(pady=10)

        peso_btns = tk.Frame(peso_frame, bg=T.BLANCO)
        peso_btns.pack(pady=10)

        tk.Button(peso_btns, text="📡 Capturar Balanza", font=T.FONT_BOTON, bg=T.AZUL, 
                  fg=T.TEXTO_CLARO, relief="flat", cursor="hand2", 
                  command=self._capturar_peso).pack(side="left", padx=10)
        tk.Label(peso_btns, text="o ingrese manual:", font=T.FONT_NORMAL, 
                 bg=T.BLANCO, fg=T.GRIS_OSCURO).pack(side="left", padx=5)

        self.entry_peso = tk.Entry(peso_btns, font=T.FONT_MONO, bg=T.GRIS_CLARO, 
                                    fg=T.TEXTO, width=10, justify="right", relief="solid", bd=1)
        self.entry_peso.pack(side="left", padx=10)
        self.entry_peso.insert(0, "0")

        # Cálculo
        calc_frame = tk.Frame(peso_frame, bg=T.BLANCO)
        calc_frame.pack(pady=15)

        tk.Button(calc_frame, text="🔄 CALCULAR PESOS", font=T.FONT_BOTON, bg=T.ROJO, 
                  fg=T.TEXTO_CLARO, relief="flat", cursor="hand2", 
                  command=self._calcular).pack(pady=5)

        self.lbl_bruto = tk.Label(calc_frame, text="Peso Bruto: ---", 
                                   font=T.FONT_NORMAL, bg=T.BLANCO, fg=T.TEXTO)
        self.lbl_bruto.pack()

        self.lbl_tara = tk.Label(calc_frame, text="Tara: ---", 
                                  font=T.FONT_NORMAL, bg=T.BLANCO, fg=T.TEXTO)
        self.lbl_tara.pack()

        self.lbl_neto = tk.Label(calc_frame, text="Peso Neto: ---", 
                                  font=T.FONT_MONO, bg=T.BLANCO, fg=T.VERDE)
        self.lbl_neto.pack(pady=5)

        # Observaciones
        obs_frame = tk.Frame(scroll_frame, bg=T.BLANCO, relief="solid", bd=1)
        obs_frame.pack(fill="x", padx=20, pady=10)

        tk.Label(obs_frame, text="Observaciones:", font=T.FONT_LABEL, 
                 bg=T.BLANCO, fg=T.TEXTO).pack(anchor="w", padx=15, pady=(10, 0))

        self.text_obs = tk.Text(obs_frame, font=T.FONT_NORMAL, bg=T.GRIS_CLARO, 
                                 fg=T.TEXTO, height=3, width=50, relief="solid", bd=1)
        self.text_obs.pack(fill="x", padx=15, pady=(0, 10))

        # Botones
        btn_frame = tk.Frame(scroll_frame, bg=T.FONDO)
        btn_frame.pack(pady=20)

        tk.Button(btn_frame, text="✅ GUARDAR Y CERRAR TICKETS", font=T.FONT_BOTON, 
                  bg=T.VERDE, fg=T.TEXTO_CLARO, relief="flat", cursor="hand2", 
                  padx=30, pady=10, command=self._guardar).pack(side="left", padx=15)
        tk.Button(btn_frame, text="❌ Cancelar", font=T.FONT_BOTON, bg=T.ROJO, 
                  fg=T.TEXTO_CLARO, relief="flat", cursor="hand2", padx=20, pady=10, 
                  command=self._show_tickets_disponibles).pack(side="left", padx=15)

    def _capturar_peso(self):
        """Captura peso de balanza (simulado)"""
        import random
        peso = random.randint(5000, 25000)
        self.lbl_peso.configure(text=f"{peso:,} kg")
        self.entry_peso.delete(0, tk.END)
        self.entry_peso.insert(0, str(peso))
        messagebox.showinfo("Balanza", f"Peso capturado: {peso:,} kg")

    def _calcular(self):
        """Calcula los pesos según el tipo de operación"""
        try:
            peso_egreso = float(self.entry_peso.get().strip().replace(",", "."))
        except:
            messagebox.showwarning("Error", "Peso inválido")
            return

        peso_ingreso = self.ticket_ingreso.get('peso_kg', 0)

        if self.tipo_op == "vacio":
            # Camión vacío: el peso de egreso es la tara
            peso_bruto = peso_ingreso
            peso_tara = peso_egreso
        else:
            # Camión con mercancía: el peso de egreso es el bruto
            peso_bruto = peso_egreso
            peso_tara = peso_ingreso

        peso_neto = peso_bruto - peso_tara

        self.lbl_bruto.configure(text=f"Peso Bruto: {peso_bruto:,.0f} kg")
        self.lbl_tara.configure(text=f"Tara: {peso_tara:,.0f} kg")
        self.lbl_neto.configure(text=f"Peso Neto: {peso_neto:,.0f} kg")

        self.peso_bruto = peso_bruto
        self.peso_tara = peso_tara
        self.peso_neto = peso_neto

    def _guardar(self):
        """Guarda el ticket de egreso y cierra ambos tickets"""
        if not hasattr(self, 'peso_neto'):
            messagebox.showwarning("Error", "Primero calcule los pesos")
            return

        try:
            peso_egreso = float(self.entry_peso.get().strip().replace(",", "."))
        except:
            messagebox.showwarning("Error", "Peso inválido")
            return

        if not messagebox.askyesno("Confirmar", 
            f"¿Confirmar egreso?\n\n"
            f"Ticket ingreso: {self.ticket_ingreso['numero_ticket']} (se cerrará)\n"
            f"Ticket egreso: {self.ticket_egreso}\n"
            f"Peso neto: {self.peso_neto:,.0f} kg"):
            return

        datos = {
            "numero_ticket": self.ticket_egreso,
            "tipo_ticket": "egreso",
            "tipo_operacion": self.tipo_op,
            "patente_chasis": self.ticket_ingreso.get('patente_chasis', ''),
            "patente_acoplado": self.ticket_ingreso.get('patente_acoplado', ''),
            "transportista": self.ticket_ingreso.get('transportista', ''),
            "cuit_transportista": self.ticket_ingreso.get('cuit_transportista', ''),
            "dni_chofer": self.ticket_ingreso.get('dni_chofer', ''),
            "chofer": self.ticket_ingreso.get('chofer', ''),
            "usuario_carga": self.ticket_ingreso.get('usuario_carga', ''),
            "num_habilitacion": self.ticket_ingreso.get('num_habilitacion', ''),
            "precintos": self.ticket_ingreso.get('precintos', ''),
            "observaciones": self.text_obs.get("1.0", tk.END).strip(),
            "peso_kg": peso_egreso,
            "peso_manual": 1,
            "ticket_ingreso_id": self.ticket_ingreso['id'],
            "peso_bruto_kg": self.peso_bruto,
            "peso_tara_kg": self.peso_tara,
            "peso_neto_kg": self.peso_neto,
            "operador": Sesion.nombre_usuario(),
        }

        try:
            # Usar la función que guarda egreso y cierra ingreso
            guardar_ticket_egreso(datos)
            self._show_success(datos)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar:\n{e}")

    def _show_success(self, datos):
        """Muestra pantalla de éxito"""
        for w in self.content.winfo_children():
            w.destroy()

        frame = tk.Frame(self.content, bg=T.BLANCO, relief="solid", bd=2)
        frame.pack(expand=True, pady=50, padx=100)

        tk.Label(frame, text="✅ TICKETS CERRADOS CORRECTAMENTE", 
                 font=T.FONT_TITULO, bg=T.BLANCO, fg=T.VERDE).pack(pady=30)

        resumen = f"Ticket Egreso: {datos['numero_ticket']} ✓ CERRADO\n"
        resumen += f"Ticket Ingreso: {self.ticket_ingreso['numero_ticket']} ✓ CERRADO\n"
        resumen += f"Fecha: {datetime.now().strftime('%d/%m/%Y %H:%M')}\n\n"
        resumen += f"Patente: {datos['patente_chasis']} / {datos['patente_acoplado']}\n\n"
        resumen += f"Peso Bruto: {datos['peso_bruto_kg']:,.0f} kg\n"
        resumen += f"Tara: {datos['peso_tara_kg']:,.0f} kg\n"
        resumen += f"PESO NETO: {datos['peso_neto_kg']:,.0f} kg"

        tk.Label(frame, text=resumen, font=T.FONT_NORMAL, bg=T.BLANCO, 
                 fg=T.TEXTO, justify="left").pack(padx=30, pady=20)

        btns = tk.Frame(frame, bg=T.BLANCO)
        btns.pack(pady=20)

        tk.Button(btns, text="📤 Nuevo Egreso", font=T.FONT_BOTON, bg=T.AZUL, 
                  fg=T.TEXTO_CLARO, relief="flat", cursor="hand2", padx=15, pady=8, 
                  command=self._show_tickets_disponibles).pack(side="left", padx=10)
        tk.Button(btns, text="🏠 Volver al menú", font=T.FONT_BOTON, bg=T.GRIS_OSCURO, 
                  fg=T.TEXTO_CLARO, relief="flat", cursor="hand2", padx=15, pady=8, 
                  command=self.on_back).pack(side="left", padx=10)
