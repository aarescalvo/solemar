@echo off
title Frigorifico Solemar v1.6.0
cls
echo ================================================================
echo  FRIGORIFICO SOLEMAR - v1.6.0
echo  Sistema Completo de Gestion
echo ================================================================
echo.
python main.py
if errorlevel 1 (
    echo.
    echo [ERROR] Verifique que Python este instalado.
    pause
)
