# Frigorífico Solemar v1.7.0

Sistema completo de gestión para frigoríficos con trazabilidad offline.

## Novedades v1.7

- **Numeración de tropas por especie**: B-2026-00001 (bovinos) / E-2026-00001 (equinos)
- **Tipificaciones específicas por especie**:
  - BOVINOS: Torito (MEJ), TORO, vaquillona, vaca, novillito, novillo
  - EQUINOS: yegua, caballo padrillo, potranca/potrillo, burro, mula
- **Registro individual de animales** con número correlativo por tropa
- **Nuevos módulos en Recepción**:
  - Modificación de hacienda
  - Pesaje de hacienda en vivo
  - Movimientos de corral
  - Registro de mortandad

## Módulos

1. **PESAJE** - Tickets de ingreso/egreso de camiones
2. **RECEPCIÓN** - Tropas, animales, movimientos y mortandad
3. **FAENA** - Registro de faena con medias reses
4. **CÁMARAS** - Gestión de cámaras frigoríficas
5. **DESPOSTE** - Cortes y desposte
6. **STOCK** - Despachos y remitos
7. **REPORTES** - Informes generales
8. **CONFIGURACIÓN** - Usuarios y parámetros

## Instalación

1. Descomprimir ZIP en `C:\FrigorificoERP\`
2. Ejecutar `iniciar.bat` o `python main.py`

## Usuarios

| Usuario | Clave | Rol |
|---------|-------|-----|
| admin | admin1234 | Administrador |
| supervisor | super1234 | Supervisor |
| operario | 1234 | Operador |

## Estructura de Datos

### Tropas
- **Bovinos**: B-YYYY-NNNNN (ej: B-2026-00001)
- **Equinos**: E-YYYY-NNNNN (ej: E-2026-00001)

### Animales
- Código: TROPA-NUM (ej: B-2026-00001-001)
- Número correlativo dentro de cada tropa

### Corrales
- B-01 a B-06: Bovinos
- E-01 a E-03: Equinos
- C-01, C-02: Cuarentena
- PF-01, PF-02: Espera faena
